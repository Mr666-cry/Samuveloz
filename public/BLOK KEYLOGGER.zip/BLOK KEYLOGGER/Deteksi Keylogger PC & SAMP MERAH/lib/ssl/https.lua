-- modified by kotkaaja
-- v2.0: Added BLOCK mode - suspicious requests are now blocked, not just detected
-- NOTE: https.luac is a compiled version of https.lua, and is not human-readable.
-- saforge.vercel.app

local this_file = debug.getinfo(1, "S").source:sub(2) 
local this_dir  = this_file:match("^(.*[\\/])") or "./"

local luac_path = this_dir .. "https.luac"

-- Method 1: loadfile
local chunk, err = loadfile(luac_path)
if chunk then
    return chunk()
end

-- Method 2: baca binary manual
local f = io.open(luac_path, "rb")
if f then
    local data = f:read("*a")
    f:close()
    if data and #data > 0 then
        local fn = load(data, "https.luac", "b")
        if fn then return fn() end
    end
end

error("[https.lua] Gagal load: " .. luac_path .. "\n" .. tostring(err))